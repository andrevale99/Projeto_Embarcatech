#!/bin/bash

cp -v /home/andre/Documents/Git/Projeto_Embarcatech/Projeto/build/Projeto.uf2 /run/media/andre/RPI-RP2/

exit 0